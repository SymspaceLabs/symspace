//
//  WaveWorldTabBarController.m
//  Unity-iPhone
//
//  Created by Oleg Kalashnik on 22.11.2021.
//

#import <Foundation/Foundation.h>
#import "WaveWorldTabBarController.h"
#import "IOSTryOnPlugin.h"

@implementation WaveWorldTabBarController

- (void)viewDidLoad{
    [super viewDidLoad];
   // NSLog(@"##TabBar Bounds: width: %f heigh: %f",  [tabVC.tabBar bounds].size.width, [tabVC.tabBar bounds].size.height);
    UITabBar *tabBar = [[UITabBar alloc] initWithFrame:CGRectMake(0, 0, 320, 50)];
    tabBar.delegate=self;   //here you need import the protocol <UITabBarDelegate>
    [self.view addSubview:tabBar];
    
    NSMutableArray *tabBarItems = [[NSMutableArray alloc] init];

    UITabBarItem *tabBarItem0 = [[UITabBarItem alloc] initWithTitle:@"Home" image:[UIImage imageNamed:@"HomeIconSelected"] tag:0];
    UITabBarItem *tabBarItem1 = [[UITabBarItem alloc] initWithTitle:@"Fitting Room" image:[UIImage imageNamed:@"HomeIconSelected"] tag:1];
    UITabBarItem *tabBarItem2 = [[UITabBarItem alloc] initWithTitle:@"AR Visuals" image:[UIImage imageNamed:@"HomeIconSelected"] tag:2];
    UITabBarItem *tabBarItem3 = [[UITabBarItem alloc] initWithTitle:@"AR Art" image:[UIImage imageNamed:@"HomeIconSelected"] tag:3];
    UITabBarItem *tabBarItem4 = [[UITabBarItem alloc] initWithTitle:@"Profile" image:[UIImage imageNamed:@"HomeIconSelected"] tag:4];

    [tabBarItems addObject:tabBarItem0];
    [tabBarItems addObject:tabBarItem1];
    [tabBarItems addObject:tabBarItem2];
    [tabBarItems addObject:tabBarItem3];
    [tabBarItems addObject:tabBarItem4];

    tabBar.items = tabBarItems;
    tabBar.selectedItem = [tabBarItems objectAtIndex:3];
    
   /* self.tabBar.frame = CGRectMake(0, self.view.bounds.size.height - self.tabBar.bounds.size.height * 2, self.tabBar.bounds.size.width, self.tabBar.bounds.size.height * 2);*/
    //[IOSTryOnPlugin callUnityObject:"TOARArtCanvas" Method:"NativeCommand" Parameter:"Start scanning"];
   /*_tabBar.delegate = self;
    [_tabBar setHidden:true];
    [_tabBar setSelectedItem:[_tabBar.items objectAtIndex:0]];
    UIScrollView * scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    scrollView.backgroundColor = UIColor.purpleColor;
    scrollView.contentSize = CGSizeMake(self.view.bounds.size.width * 2, self.view.bounds.size.height);
    UIView *view0 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
    view0.backgroundColor = UIColor.blueColor;
    UIView *view1 = [[UIView alloc] initWithFrame:CGRectMake(self.view.bounds.size.width, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
    view1.backgroundColor = UIColor.yellowColor;
    [scrollView addSubview:view0];
    [scrollView addSubview:view1];
    scrollView.pagingEnabled = true;
    scrollView.delegate = self;
    [self.view addSubview:scrollView];*/
    
    
}

- (void)viewWillAppear:(BOOL)animated
{
    NSLog(@"viewDidAppear");
   // _tabBar.delegate = self;
}

- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    NSLog(@"Tag %li", (long)item.tag);
   // [_tabBar setSelectedItem:[_tabBar.items objectAtIndex:item.tag]];
    self.view.backgroundColor = UIColor.redColor;
}

@end
