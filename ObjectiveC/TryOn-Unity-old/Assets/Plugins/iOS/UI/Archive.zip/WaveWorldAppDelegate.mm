//
//  WaveWorldAppDelegate.m
//  Unity-iPhone
//
//  Created by Oleg Kalashnik on 22.11.2021.
//

#import <Foundation/Foundation.h>
#import "UnityAppController.h"
#import "WaveWorldTabBarController.h"
#include "UI/UnityView.h"
@interface WaveWorldAppDelegate : UnityAppController <UITabBarControllerDelegate>
{
    
}

@end

@implementation WaveWorldAppDelegate

- (void)willStartWithViewController:(UIViewController*)controller {
   /* _rootController = [[WaveWorldTabBarController alloc] initWithNibName:@"WaveWorldTabBarController" bundle:[NSBundle mainBundle]];*/
    //_rootController.view.bounds =[[UIScreen mainScreen] bounds];
    //WaveWorldTabBarController *tabVC = [[WaveWorldTabBarController alloc] initWithNibName:@"WaveWorldTabBarController" bundle:[NSBundle mainBundle]];
    WaveWorldTabBarController *tabVC = [[WaveWorldTabBarController alloc] init];
    /*WaveWorldHomeViewController *homeVC = [[WaveWorldHomeViewController alloc] initWithNibName:@"WaveWorldHomeViewController" bundle:[NSBundle mainBundle]];
    homeVC.title = @"Home";
    UIImage *homeIcon = [UIImage imageNamed:@"HomeIcon"];
    homeVC.tabBarItem.image = homeIcon;
   // homeVC.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"Home" image:[UIImage imageNamed:@"HomeIcon"] selectedImage:[UIImage imageNamed:@"HomeIcon"]];
    WaveWorldFittingRoomViewController *fittingRoomVC = [[WaveWorldFittingRoomViewController alloc] initWithNibName:@"WaveWorldFittingRoomViewController" bundle:[NSBundle mainBundle]];
    fittingRoomVC.title = @"Fitting Room";
    fittingRoomVC.tabBarItem.image =[UIImage imageNamed:@"FittingRoomIcon"];
    //fittingRoomVC.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"Fitting Room" image:[UIImage imageNamed:@"FittingRoomIcon"] selectedImage:[UIImage imageNamed:@"FittingRoomIcon"]];
    WaveWorldVisualsViewController *visualsVC = [[WaveWorldVisualsViewController alloc] initWithNibName:@"WaveWorldVisualsViewController" bundle:[NSBundle mainBundle]];
    visualsVC.title = @"AR Visuals";
    visualsVC.tabBarItem.image =[UIImage imageNamed:@"VisualsIcon"];
    //visualsVC.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"AR Visuals" image:[UIImage imageNamed:@"VisualsIcon"] selectedImage:[UIImage imageNamed:@"VisualsIcon"]];
    WaveWorldArtViewController *artVC = [[WaveWorldArtViewController alloc] initWithNibName:@"WaveWorldArtViewController" bundle:[NSBundle mainBundle]];
    artVC.title = @"AR Art";
    artVC.tabBarItem.image =[UIImage imageNamed:@"ArtIcon"];
    //artVC.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"AR Art" image:[UIImage imageNamed:@"ArtIcon"] selectedImage:[UIImage imageNamed:@"ArtIcon"]];
    WaveWorldProfileViewController *profileVC = [[WaveWorldProfileViewController alloc] initWithNibName:@"WaveWorldProfileViewController" bundle:[NSBundle mainBundle]];
    profileVC.title = @"Profile";
    profileVC.tabBarItem.image =[UIImage imageNamed:@"ProfileIcon"];
    //profileVC.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"Profile" image:[UIImage imageNamed:@"ProfileIcon"] selectedImage:[UIImage imageNamed:@"ProfileIcon"]];
    //tabVC.viewControllers  = @[homeVC, fittingRoomVC, visualsVC, artVC, profileVC];
    UIViewController *vc = [[UIViewController alloc] init];
    vc.view = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    vc.view.backgroundColor = [UIColor redColor];
    vc.title = @"Test";
    UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:profileVC];
    NSLog(@"##Root Bounds: width: %f heigh: %f",  _rootController.view.bounds.size.width, _rootController.view.bounds.size.height);
    NSLog(@"##Screen Bounds: width: %f heigh: %f",  [[UIScreen mainScreen] bounds].size.width, [[UIScreen mainScreen] bounds].size.height);
    //NSLog(@"##TabBar Bounds: width: %f heigh: %f",  [tabVC.tabBar bounds].size.width, [tabVC.tabBar bounds].size.height);
    NSLog(@"##Window Root View Controller Bounds: width: %f heigh: %f",  [_window.rootViewController.view bounds].size.width, [_window.rootViewController.view bounds].size.height);
    NSLog(@"##Window Root Hash: %@ Root View Controller %@",  _window.rootViewController, _rootController);
    */
    
    
    //_rootController  = tabVC;
    //_rootController.view = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    //_rootController.view.backgroundColor = [UIColor systemPinkColor];
    // Setup Unity View
    
    //_window.rootViewController = tabVC;
    //_unityView.contentScaleFactor   = UnityScreenScaleFactor([UIScreen mainScreen]);
    //_unityView.autoresizingMask     = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _rootController = [[UIViewController alloc] init];
    [_rootController.view addSubview:tabVC.view];
    _unityView.frame = _rootController.view.bounds;
    _rootView =_rootController.view;
    _rootView.contentScaleFactor = UnityScreenScaleFactor([UIScreen mainScreen]);
    _rootView.autoresizingMask     = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
   // [tabVC.viewControllers[tabVC.selectedIndex].view addSubview:_unityView];
    //[tabVC setDelegate:self];
    //[_rootController.view addSubview:tabVC.view];
    //tabVC.view.contentScaleFactor = UnityScreenScaleFactor([UIScreen mainScreen]);
    //tabVC.view.autoresizingMask     = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    //tabVC.view.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height * 0.95f);
    //[_rootController.view addSubview:_unityView];
    //[_rootController.view sendSubviewToBack:_unityView];
    //[_rootController.view bringSubviewToFront:tabVC.view];
    //[_window.rootViewController presentViewController:navController animated:YES completion:nil];
   // [tabVC.view setNeedsLayout];
   // [tabVC.tabBar setNeedsLayout];
    //[_rootController presentViewController:navController animated:YES completion:nil];
    NSLog(@"##Root view controller conten scale: %f",  _rootView.contentScaleFactor);
  /*  WaveWorldTabBarController *tabBarController = [[WaveWorldTabBarController alloc] initWithNibName:@"WaveWorldTabBarController" bundle:[NSBundle mainBundle]];

    [_rootView addSubview:tabBarController.view];*/
   //[_rootController.view addSubview:_unityView];
   //[_rootController.view sendSubviewToBack:_unityView];
    /*
        _rootController = [[UIViewController alloc] init];
        _rootView       = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
        UITabBarController *tabVC = [sb instantiateViewControllerWithIdentifier:@"TabBar"];

    UIViewController *vc1 = [sb instantiateViewControllerWithIdentifier:@"ViewController1"];
    UIViewController *vc2 = [sb instantiateViewControllerWithIdentifier:@"ViewController2"];
        [tabVC addChildViewController:vc1];
    [tabVC addChildViewController:vc2];
      //  [[UIApplication sharedApplication] keyWindow].rootViewController = tabVC;
    [_rootController.view addSubview:tabVC.view];*/
}

#pragma  mark - UITabBarControllerDelegate

- (void)tabBarController:(UITabBarController *)tabBarController
 didSelectViewController:(UIViewController *)viewController
{
    NSLog(@"New tab bar index: %ld", tabBarController.selectedIndex);
}

@end

IMPL_APP_CONTROLLER_SUBCLASS(WaveWorldAppDelegate)
