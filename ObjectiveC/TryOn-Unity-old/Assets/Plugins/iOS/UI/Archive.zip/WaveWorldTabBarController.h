//
//  WaveWorldTabBarController.h
//  Unity-iPhone
//
//  Created by Oleg Kalashnik on 22.11.2021.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface WaveWorldTabBarController : UIViewController <UITabBarDelegate>
{
    
}

//@property(nonatomic, strong)IBOutlet id<UITabBarDelegate> delegate;

@end
